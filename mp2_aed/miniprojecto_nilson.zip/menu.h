//
//  menu.h
//  MiniProjecto2 AED
//
//  Created by Nilson Lopes on 25/06/14.
//  Copyright (c) 2014 Nilson Lopes. All rights reserved.
//

#ifndef _libmenu_h
#define _libmenu_h

void printf_logo();
int menu_principal(void);
int submenu(char titulo[]);

#endif
