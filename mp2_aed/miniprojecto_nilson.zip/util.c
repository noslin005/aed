//
//  util.c
//  MiniProjecto2 AED
//
//  Created by Nilson Lopes on 23/06/14.
//  Copyright (c) 2014 Nilson Lopes. All rights reserved.
//

#include "util.h"
#include <stdio.h>

void flush_buffer(void){
    clean_buffer;
}

void pause(void)
{
    printf("\n\t\tTecle Enter para continuar ...");
    flush_buffer();
    getchar();
}
